"""
Create a sequence distribution plot
==================================================


Objective
------------
write objective here


Solution
------------
write solution here

"""

import pysan as ps

sequence = [1,1,1,2,2,3,2,2,3,3,2,1,1,2,3,3,3,2,2,2,3,2,1,1]

ps.plot_sequence(sequence)